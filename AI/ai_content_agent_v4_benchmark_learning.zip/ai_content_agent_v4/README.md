# AI Content Agent v3 — Benchmark-Driven Instagram Agent

목표:
'잘 되는 AI 인스타그램 계정'을 벤치마킹하고, 그 분석 결과를 우리 계정의
콘텐츠 전략 / 톤앤매너 / 카드 구조 / 주제 비율 / Hook / CTA / 디자인 규칙으로 변환한다.

핵심 파이프라인:
1. benchmark_discovery
2. account_analysis
3. content_pattern_analysis
4. tone_analysis
5. strategy_synthesis
6. topic_scoring
7. carousel_generation
8. qa
9. performance_learning

중요:
- 벤치마크 계정의 게시물을 그대로 복제하지 않는다.
- '패턴'과 '원리'를 추출하고 우리 브랜드에 맞게 재설계한다.
- 최신 사실은 원출처 우선 검증한다.
- 실제 성과 데이터(조회, 저장, 공유, 프로필 방문 등)가 없으면 추정치와 사실을 구분한다.

실행 예:
`/benchmark-ai-instagram`
`/create-carousel "직장인이 바로 써먹는 ChatGPT 업무 자동화 5가지"`

추천 벤치마크:
- @ai_freaks.kr
- @therundownai
- 추가 계정은 benchmark/accounts.json에 등록

우리 브랜드 기본 방향:
- 브랜드: AI 실제 활용법
- 핵심 가치: 'AI를 어렵게 설명하지 않고, 오늘 바로 써먹게 만든다.'
- 대상: AI를 써보고 싶지만 프롬프트/툴 선택/활용법에서 막히는 일반 사용자와 직장인
- 기본 포맷: Instagram Carousel + Reels

# QA Agent

다음 항목을 0~2점으로 평가하고 16점 미만이면 재작성한다.

1. Hook strength
2. Practical value
3. Clarity
4. Saveability
5. Shareability
6. Brand fit
7. Tone consistency
8. Originality
9. Factual accuracy
10. Visual readability

추가로:
- 벤치마크 계정의 문구를 그대로 베낀 흔적
- 근거 없는 숫자
- 최신성 오류
- 과장/공포 마케팅
- 카드 간 반복
을 검사한다.

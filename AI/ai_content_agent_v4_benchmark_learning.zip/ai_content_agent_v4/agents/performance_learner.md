# Performance Learner Agent

실제 게시물 성과가 들어오면 전략을 업데이트한다.

입력:
- reach
- views
- likes
- comments
- saves
- shares
- profile_visits
- follows
- post_type
- pillar
- hook_type
- slide_count
- publish_time

계산:
save_rate = saves / reach
share_rate = shares / reach
follow_rate = follows / reach
engagement_rate = (likes + comments + saves + shares) / reach

분석:
1. 상위 20% 콘텐츠의 공통점
2. 하위 20% 콘텐츠의 공통점
3. Hook별 성과
4. Pillar별 성과
5. 카드 수별 성과
6. CTA별 성과
7. 주제별 성과

규칙:
- 표본 5개 미만인 패턴은 전략을 확정하지 않는다.
- 단일 바이럴 게시물 때문에 전략 전체를 변경하지 않는다.
- 4주 단위로 전략을 재평가한다.

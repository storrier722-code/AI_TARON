# Topic Scorer Agent

각 주제를 다음 100점으로 평가한다.

- Save potential 20
- Share potential 20
- Immediate usefulness 20
- Curiosity/hook 15
- Timeliness 10
- Search/discovery value 5
- Brand fit 10

70점 미만이면 자동 제작하지 않는다.
85점 이상이면 우선 제작한다.

뉴스/업데이트 주제는 freshness를 별도 검증한다.

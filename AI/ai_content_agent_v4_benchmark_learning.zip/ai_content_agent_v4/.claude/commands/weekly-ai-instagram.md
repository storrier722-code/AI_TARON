# /weekly-ai-instagram

주 1회 실행하는 전체 전략 루틴.

1. instagram_researcher
2. benchmark_analysis
3. strategy_synthesis
4. 최근 AI 뉴스/기능 조사
5. 20개 후보 주제 생성
6. topic_scorer로 100점 평가
7. TOP 5 선정
8. 각 주제에 대해:
   - Hook 3개
   - carousel outline
   - caption angle
9. 주간 콘텐츠 캘린더 생성

출력:
reports/weekly_strategy.md
data/topic_backlog.json

# /learn-from-performance

실제 Instagram 성과 CSV/JSON을 입력받아 전략을 학습한다.

필수 컬럼:
date, post_id, format, pillar, hook_type, reach, views, likes, comments, saves, shares, profile_visits, follows

실행:
1. performance_learner
2. KPI 계산
3. 상/하위 콘텐츠 비교
4. 기존 전략과 충돌 여부 확인
5. brand_profile에 적용할 변경안 생성
6. 변경 전/후 전략을 reports/performance_learning_report.md에 기록

자동으로 전략을 덮어쓰지 말고 '추천 변경안'을 먼저 만든다.

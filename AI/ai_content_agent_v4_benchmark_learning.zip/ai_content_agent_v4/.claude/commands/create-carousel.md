# /create-carousel

입력 주제를 받으면:

1. brand_profile.json 로드
2. 최근 benchmark_report 로드
3. topic_scorer로 주제 점수 계산
4. 최신 사실 조사 및 출처 확인
5. carousel_writer로 원고 생성
6. QA
7. 최종 carousel.json 생성

최종 산출:
- carousel.md
- carousel.json
- caption.md
- sources.md

콘텐츠는 벤치마크 계정의 문구/이미지를 복제하지 않는다.
성공 패턴만 추출하여 브랜드 고유 콘텐츠로 만든다.

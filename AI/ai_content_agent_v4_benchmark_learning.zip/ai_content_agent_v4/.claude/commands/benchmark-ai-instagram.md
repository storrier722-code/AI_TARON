# /benchmark-ai-instagram

목표: 현재 AI Instagram 생태계를 조사해 우리 계정의 콘텐츠 운영 규칙을 업데이트한다.

실행 순서:
1. benchmark/accounts.json 로드
2. 각 계정의 최신 공개 정보 조사
3. 게시물/콘텐츠 패턴 수집
4. account_analysis 실행
5. strategy_synthesis 실행
6. config/brand_profile.json의 전략 제안 업데이트
7. reports/benchmark_report.md 생성

출력 보고서:
- 벤치마크 계정별 요약
- 잘 작동하는 콘텐츠 유형
- Hook 패턴
- 카드 구조
- 톤앤매너
- 시각 규칙
- CTA
- 우리가 가져올 것
- 가져오지 않을 것
- 차별화 기회
- 다음 30개 콘텐츠 주제

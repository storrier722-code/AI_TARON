from pathlib import Path
import json
from datetime import datetime

ROOT = Path(__file__).parent
TOPIC = (ROOT / "topic.txt").read_text(encoding="utf-8").strip()
OUT = ROOT / "output"
OUT.mkdir(exist_ok=True)

def research_plan(topic):
    return f"""# 리서치 계획

주제: {topic}

## 조사 질문
1. 이 주제에서 일반 사용자가 가장 많이 하는 실수는 무엇인가?
2. 실제 업무에서 바로 적용할 수 있는 방법은 무엇인가?
3. 초보자도 이해할 수 있는 예시는 무엇인가?
4. 현재 기준으로 변경될 수 있는 정보는 무엇인가?
5. 과장되거나 근거가 약한 주장은 무엇인가?

## 검증 원칙
- 숫자/가격/정책/제품 기능은 최신 출처 확인
- 출처 없는 단정 금지
- 경험담과 사실을 구분
- 모르면 추측하지 않고 '확인 필요' 표시
"""

def carousel(topic):
    cards = [
        ("01", "HOOK", f"{topic}", "AI를 잘 쓰는 사람은 프롬프트부터 쓰지 않습니다."),
        ("02", "PROBLEM", "왜 결과가 별로 나올까?", "AI에게 원하는 결과의 기준이 없으면 답변도 흔들립니다."),
        ("03", "KEY", "먼저 '결과물'을 정하세요", "누가 읽는지 / 어디에 쓰는지 / 어떤 형태인지부터 정합니다."),
        ("04", "METHOD", "3가지만 정하면 됩니다", "① 목적 ② 대상 ③ 결과물 형식"),
        ("05", "EXAMPLE", "예를 들어 이렇게", "나쁜 요청 → 'AI 마케팅 글 써줘'\\n좋은 요청 → '30대 직장인 대상, 인스타 카드뉴스 8장으로 작성'"),
        ("06", "CHECK", "AI 결과도 검수해야 합니다", "사실관계·숫자·출처·과장 표현을 확인하세요."),
        ("07", "ACTION", "오늘 바로 해보세요", "하나의 업무를 골라 목적·대상·결과물 형식부터 AI에게 알려주세요."),
        ("08", "CTA", "AI를 '질문하는 도구'에서 '일하는 도구'로", "저장해두고 다음 AI 작업에 그대로 적용해보세요."),
    ]
    return cards

def write_markdown(cards):
    lines = [f"# {TOPIC}", ""]
    for n, typ, title, body in cards:
        lines += [f"## CARD {n} — {typ}", f"### {title}", body, ""]
    return "\\n".join(lines)

def make_json(cards):
    return {
        "topic": TOPIC,
        "format": "instagram_carousel",
        "aspect_ratio": "4:5",
        "cards": [
            {"number": n, "type": typ, "title": title, "body": body}
            for n, typ, title, body in cards
        ]
    }

cards = carousel(TOPIC)
(OUT / "research.md").write_text(research_plan(TOPIC), encoding="utf-8")
(OUT / "carousel.md").write_text(write_markdown(cards), encoding="utf-8")
(OUT / "carousel.json").write_text(
    json.dumps(make_json(cards), ensure_ascii=False, indent=2),
    encoding="utf-8"
)

caption = f"""# Instagram Caption

{TOPIC}

AI를 잘 활용하려면 무작정 프롬프트부터 작성하기보다
먼저 '무엇을 완성할 것인지'를 정하는 게 중요합니다.

오늘 내용이 도움이 됐다면 저장해두고
다음 AI 작업에서 그대로 적용해보세요.

#AI활용 #AI꿀팁 #생성형AI #ChatGPT #Claude #AI업무자동화
"""
(OUT / "caption.md").write_text(caption, encoding="utf-8")

print(f"완료: {datetime.now():%Y-%m-%d %H:%M}")
print("output/ 폴더의 4개 파일을 확인하세요.")

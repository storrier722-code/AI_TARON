# AI Content Agent — Instagram Card News MVP

목표:
AI 실제 활용법을 주제로 인스타그램 카드뉴스 제작 과정을 자동화한다.

## 실행 흐름
1. topic.txt에 주제를 입력
2. `python agent.py` 실행
3. output/ 아래에
   - research.md
   - carousel.md
   - carousel.json
   - caption.md
   생성

## 현재 MVP
- 주제 구조화
- 리서치용 검색 질문 생성
- 사실 검증 체크리스트
- 8장 카드뉴스 구성
- 인스타 캡션 생성
- 디자인 툴에 넘기기 쉬운 JSON 출력

## 다음 확장
- 웹 검색 API 연결
- 이미지 생성 연결
- Canva/Figma/HTML 렌더러 연결
- Instagram Graph API 게시
- 예약 발행
- 성과 데이터 기반 주제 추천

## 사용
`topic.txt`에 예:
AI에게 업무를 시킬 때 프롬프트보다 먼저 해야 하는 것

그 다음:
`python agent.py`
